# 全局变量，用于存储文件内容的缓存数据
cached_data <- list()

read <- function(file_name) {
  # 检查缓存数据中是否已经读取
  if (exists("cached_data") && file_name %in% names(cached_data)) {
    data <- cached_data[[file_name]]
  } else {
    # 从文本文件中读取内容
    data <- readLines(file_name)

    # 将内容写入缓存
    cached_data[[file_name]] <- data
  }

  # 随机选择一行内容并打印
  random_line <- sample(data, 1)
  print(random_line)
}

show_all <- function() {
  # 获取包中txt文件的路径
  package_path <- system.file("extdata", package = "easestress")

  # 遍历读取txt文件名并打印
  txt_files <- list.files(package_path, pattern = "\\.txt$", full.names = TRUE)
  for (file in txt_files) {
    file_name <- basename(file)
    print(file_name)
  }
}


